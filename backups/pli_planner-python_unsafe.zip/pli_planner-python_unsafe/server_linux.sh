#! /bin/bash
flask --app server_init run --host=0.0.0.0 --port=8002