# Tower and Towers class

import numpy as np
import re
from pykml import parser
import copy
import modules.coordinates as CO
import matplotlib as mpl, matplotlib.pyplot as plt
import itertools
import networkx as nx

# In this version, everything is derived from networkx classes
# Towers are represented as a graph.
#   - Each node represents a single tower and contains its name, UTM coordinates (3D)
#   - Each edge represents wire connections between towers
# It is assumed that all towers are within the same UTM Zone so we can use only the local coordinates

class Towers():
    def __init__(self):
        self.graph = nx.empty_graph(0)
        self.UTM_Zone = ('A', 0)
    
    def add_Tower(self, name: str, utm_Coordinates: np.ndarray, connections: list):
        # Add tower (or node) to the towers graph based on its coordinates and a list
        # of connections
        
        self.graph.add_node(name, UTM = utm_Coordinates)
        self.graph.add_edges_from(connections) # As it is, it will allow you to change 
                                         # interal connections that do not concern 
                                         # the added tower

    def loadkmlFile(self, file: str, onlineQ: bool):
        # Method that updates a tower graph using an offline file. Files need to follow Google Earth "kml"s
        # format containing paths. As paths cannot represent several branches, the will be represented
        # as path with at much one common tower per branch pair.
        # If the boolean "onlineQ" is True, height coordinates will be updated online

        # Reset graph
        self.graph = nx.empty_graph(0)
        self.UTM_Zone = ('A', 0)

        # Load raw kml file
        with open(file) as f:
            doc = parser.parse(f).getroot()
            f.close()

        # Parse data to extract paths
        paths = [] # Contains all paths within the file a graph or Towers
        tower_number = 1
        for path in doc.Document.Placemark.MultiGeometry.LineString:

            T = nx.empty_graph(0)

            # Parsing each tower latitude-longitude coordinates within a path
            path_str = np.array(re.split(',| ', path.coordinates.text.strip()))
            n_t = int(len(path_str)/3)
            path_latlon = path_str.astype(float).reshape((n_t, 3)) # Numerical conv and reshape to matrix

            # Update height from online API
            if onlineQ:
                CO.updateHeightOnline(path_latlon)

            # Conversion to UTM. All towers and bases are assumed to be within the same zone
            path_utm, Z_number, Z_letter = CO.latlon2utm(path_latlon)

            T.add_node(f'T{tower_number}', UTM=path_utm[0,:])
            tower_number += 1
            for k in range(1, n_t):
                T.add_node(f'T{tower_number}', UTM = path_utm[k,:])
                T.add_edge(f'T{tower_number-1}', f'T{tower_number}')
                tower_number += 1

            paths.append(copy.deepcopy(T))

        self.graph = deleteCommonTowers(paths)
        self.UTM_Zone = (Z_letter, Z_number)

    def coordinates_List(self):
        return np.array(list(nx.get_node_attributes(self.graph,'UTM').values()))

    def plot(self, axes):
        pos3D = nx.get_node_attributes(self.graph,'UTM')
        pos2D = {}
        for key in pos3D:
            pos2D[key] = pos3D[key][0:2]

        nx.draw_networkx(self.graph, pos = pos2D, ax=axes, with_labels = True)


#-------------------------------------- Functions -----------------------------------------------
def checkCommonTowers(T1: Towers, T2: Towers, threshold: float):
# Outputs a list of names of common towers to T1 and T2 based on a 2D distance threshold.
# The first towers of each pair is in T1 and the second in T2

    # For some reason, using height too breaks everything. Also, as it needs to wait for the API,
    # if a file is loaded several times in a rapid succesion, it will also break.

        common = []

        for pair in list(itertools.product(T1.nodes, T2.nodes)):
            if (np.linalg.norm(T1.nodes[pair[0]]['UTM'][0:2]-T2.nodes[pair[1]]['UTM'][0:2]) < threshold): 
                common.append((pair[0], pair[1]))

        return common

def deleteCommonTowers(paths: list):
    # Given a list of paths (as graphs or Towers) it removes all repeated towers, connect all paths
    # and rename towers based on distance to origin.
    
    # Remove redudant pairs of paths checks
    indeces_set = list(itertools.combinations(range(len(paths)), 2))
 
    for indeces in indeces_set:
        i = indeces[0]
        j = indeces[1]

        # Gets the list of common towers (or nodes) of paths[i] and paths[j]
        C = checkCommonTowers(paths[i], paths[j], 15)

        # Assuming only 1 common tower

        # If there is a common tower, put the same number to the tower on both paths
        if not(len(C) == 0):
            paths[j] = nx.relabel_nodes(paths[j], {C[0][1]: C[0][0]}, copy = False)

    # networkx allow you to compose two graphs. If several nodes are present on two graphs with
    # the same names, then the composition will combine those nodes into one. This allow
    # us to delete duplicate towers.

    # Composing every path with renamed towers
    T = nx.empty_graph(0)
    for graph in paths:
         T = nx.compose(graph, T)

    # Rename Towers based distance to origin.
    k = 1
    mapping = {}
    nodes_sorted = sorted(T.nodes(), key=lambda n: np.linalg.norm(T.nodes[n]['UTM']))
    for node in nodes_sorted:
        mapping[node] = f'T{k}'
        k += 1
    
    # Outputs renamed graph
    return nx.relabel_nodes(T, mapping, copy = True)