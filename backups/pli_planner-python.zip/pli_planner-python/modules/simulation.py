# Simulation class code

from matplotlib.path import Path
import numpy as np

# UAV Marker for simulation ploting. It looks as the head of and arrow

def uav_Marker(angle: float):
    """
    Output the UAV Maker rotate an angle "angle" [degrees]
    """
    scale = 1

    points = np.transpose(np.array(
        [
            [0, 0], #center
            [scale * 0.65, - scale * 0.5], #lower right 
            [0, scale], #up
            [ - scale * 0.65, - scale * 0.5], #lower left  

        ]
    ))

    mat_rot =  np.array(
        [
            [np.cos(np.deg2rad(angle)), np.sin(np.deg2rad(angle))],
            [-np.sin(np.deg2rad(angle)), np.cos(np.deg2rad(angle))],
        ]
    )

    rot_points = np.transpose(np.matmul(mat_rot, points))

    return Path(rot_points,[
        Path.MOVETO,
        Path.LINETO,
        Path.LINETO, 
        Path.LINETO, 
    ])

def get_path_points(pos_i: np.ndarray, pos_f: np.ndarray, uav_speed: float, dt: float):
    """
    Divides the path between pos_f and pos_i based on UAV speed and sim speed. Outputs the corresponding coordinates
    """

    if (pos_f == pos_i).all():
        return np.asarray([pos_f])

    delta_pos = (pos_f - pos_i)
    d = np.linalg.norm(delta_pos)
    dx = uav_speed * dt
    n_points = int(np.floor(np.linalg.norm(delta_pos) / dx))

    return np.concatenate((np.asarray([pos_i + i * dx*delta_pos/d for i in range(n_points+1)]), [pos_f]))


