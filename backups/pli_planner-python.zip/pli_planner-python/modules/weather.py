# Weather status class and functions

import numpy as np, requests

# Weather is considered homogeneus on the entire mission area and constant throughout the inspection
class Weather():

    # Init of the class with a default weather status. There is no need to check if values
    # are physical as user input is already limited on the UI.
    def __init__(self, wind_vec: np.ndarray = [0.0, 0.0, 0.0], Temperature: float = 20.0, 
                 Humidity: float = 0.3, Pressure: float = 101325.0):

        self.wind_vector = wind_vec      #[m/s] 
        self.temperature = Temperature   #[degrees Celsius]
        self.humidity = Humidity         #[-]
        self.pressure = Pressure         #[Pa]

        self.rho_air = air_Density(self) #[kg / m^3]

    def updateOnline(self, latlon: np.ndarray):
        # Location must be given as [Latitude, Longitud]

        apiKey = 'f4e4e58c9c0c4492aeb144023231005'; 
        url = 'http://api.weatherapi.com/v1/current.json?key='+apiKey+'&q='+f"{latlon[0]}"+','+f"{latlon[1]}"+'&aqi=no'

        try: response = requests.get(url, timeout=5.0)
        except: 
            print("Weather API Connection error")
            return False
    

        if response.status_code == 200:

            alpha = response.json()["current"]["wind_degree"]
            print(alpha)
            wind_speed = response.json()["current"]["wind_kph"]*1000/3600
        
            self.wind_vector = wind_speed*np.array([np.sin(alpha/180*np.pi), np.cos(alpha/180*np.pi), 0]) # [m/s]
            self.temperature = response.json()["current"]["temp_c"];              # [%]
            self.humidity = response.json()["current"]["humidity"];               # [ºC]
            self.pressure = response.json()["current"]["pressure_mb"]*100;        # [Pa]
    
            print("Online Weather loaded at: " + url)

        return True

def air_Density(weather:Weather):
    """
    From https://www.omnicalculator.com/physics/air-density#how-to-calculate-the-air-density
    (Celsius Degrees, R%, Pa) -> kg/m^3
    """
    # Vapor pressure [Pa]
    pv = 6.1078*10**(7.5*weather.temperature/(weather.temperature+273.3)) * weather.humidity

    # Air density [kg / m^3]
    return ((weather.pressure - pv)/(287.058*(weather.temperature+273.3)) + pv/(461.495*(weather.temperature+273.3)))


