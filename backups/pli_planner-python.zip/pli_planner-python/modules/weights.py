# Weights computing code

import networkx as nx
import numpy as np
from scipy.optimize import fsolve

import modules.uav as UAVS, modules.weather as WT, modules.towers as TW, modules.bases as BA

# These parameters might be loaded externally o get passed to the functions

g = 9.81     # Gravity acceleration [m/s^2]

# --------------------------------------------------------------------

def compute_Consumption(r_vector: np.ndarray, v:float, uav: UAVS.UAV, weather: WT.Weather):
    """
    USE BATTERY COMSUMPTION MODEL HERE
    What if a travel is too long and a UAV dies mid travel?

    IF R_VECTOR IS A LIST, V*LIST WONT MULTIPLY EACH COMPONENT
    """

    # Travel distance
    d = np.linalg.norm(r_vector) #[m]

    # UAV air speed as a composition of ground speed and wind speed
    v_inf = np.linalg.norm(v*r_vector/d-weather.wind_vector) #[m/s]

    # Drag 
    Dr = 0.5 *  weather.rho_air * v_inf**2 * uav.flat_Area #[kg/m^3 * m^2 / s^2 * m*2 = N]

    # Thrust and thrust angle 
    alpha_r = np.arctan( Dr / (uav.mass * g)) #[rad]
    Th = uav.mass * g / (uav.number_of_Rotors * np.cos(alpha_r)) #[N]

    # Rotational speed of the rotors [s^-1]
    Omega = 6 * Th / (weather.rho_air * uav.rotor_Blades *uav.blade_Chord * uav.rotor_Radius**3 * uav.lift_Coefficient)
    Omega = np.sqrt( Omega - 1.5 * ((v_inf * np.cos(alpha_r)) / (uav.rotor_Radius))**2)


    # Parisitic power due to drag
    P_f = Dr * v_inf #[N * m/s = W]

    # Rotor blades drag power profile [W]
    P_o = 0.125 * weather.rho_air * uav.rotor_Radius**4 * Omega**3 * uav.blade_Chord * uav.rotor_Blades * uav.drag_Coefficient
    P_o = P_o * (1 + uav.K_mu * (v_inf * np.cos(alpha_r) / (Omega * uav.rotor_Radius))**2)

    # Auxiliary param and induced speed [m/s]. Gamma can be solved analitically (?)
    f = lambda Gamma: Gamma - v_inf * np.sin(alpha_r) - Th / (2 * weather.rho_air * np.pi * uav.rotor_Radius**2) / np.sqrt(Gamma**2 + (v_inf * np.cos(alpha_r))**2)
    v_i = fsolve(f, v_inf)[0] - v_inf * np.sin(alpha_r)

    # Speed up rotor power [N * m/s = W]
    P_i = uav.kappa * Th * v_i

    # Total mechanical power [W]
    P_a = uav.number_of_Rotors * ( P_i + P_o ) + P_f

    # Electrical Power [W]
    P_e = P_a / uav.eta
    
    # Energy consumed as a fraction of the UAV capacity
    # It can be bigger than one if the travel is too long.
    # Might be a good idea to check this somehow to warn the user.

    return (P_e * d/v) / uav.battery.capacity_Joules()

def compute_edge_Weights(node1:tuple, node2:tuple, uavs: UAVS.UAV_Team, weather: WT.Weather):
    """
    It takes an edge as a ordered pair of nodes Node1, Node2 each with
    the corresponding attributes and a UAV team.
    Then it computes the corresponding time and energy weights depending type.

    node = (Name, dict_Attributes)
    type can be computed from the two nodes attributes
    """

    travel_vector = node2[1]['UTM']-node1[1]['UTM']
    d = np.linalg.norm(travel_vector)

    W_t = {}
    W_e = {}

    # Line segment edge
    if node1[1]['type'] == 'Tower' and node2[1]['type'] == 'Tower':

        # UAVs are distinguished using their IDs, not their names
        for uav in uavs.list:

            i_speed = uav.missionSettings['Insp. speed']

            # As it is independent of the UAV, time can be computed beforehand
            W_t[uav.id] = d / i_speed

            
            W_e[uav.id] = compute_Consumption(travel_vector, i_speed, uav, weather)  # + whatever
    
    # Base-Tower or Tower-Base edge
    else:
    
        # UAVs are distinguished using their IDs, not their names
        for uav in uavs.list:

            c_speed = uav.missionSettings['Nav. speed']

            # As it is independent of the UAV, time can be computed beforehand
            W_t[uav.id] = d / c_speed

            
            W_e[uav.id] = compute_Consumption(travel_vector, c_speed, uav, weather)

    return W_t, W_e

def compute_abstract_edge_Weights(node1: tuple, node2: tuple, uavs: UAVS.UAV_Team, weather: WT.Weather):
    """
    Arguments depend on case
     - Base to Tower: node1 is a tuple ('Name', UTM); node2 is a list (tower1, tower2) with toweri = ('Name', UTM)
     - Tower to Base: node2 is a tuple ('Name', UTM); node1 is a list (tower1, tower2) with toweri = ('Name', UTM)
     - Tower to Tower: node1 and node2 are lists (tower1, tower2) with toweri = ('Name', UTM)
    """

    W_t = {}
    W_e1 = {}
    W_e2 = {}

    # Parsing cases

    # Base to Tower
    if node1[0][0] == 'B':

        travel_vector = node2[0][1] - node1[1]
        d_travel = np.linalg.norm(travel_vector)

        insp_vector = node2[1][1] - node2[0][1]
        d_insp = np.linalg.norm(insp_vector)

        # UAVs are distinguished using their IDs, not their names
        for uav in uavs.list:

            c_speed = uav.missionSettings['Nav. speed']
            i_speed = uav.missionSettings['Insp. speed']

            W_t[uav.id] = d_insp / i_speed + d_travel / c_speed

            W_e1[uav.id] = compute_Consumption(travel_vector, c_speed, uav, weather)
            W_e2[uav.id] = compute_Consumption(insp_vector, i_speed, uav, weather)

        #print('BT')
        return W_t, {key: W_e1[key] + W_e2[key] for key in W_e1}
    
    # Tower to Base
    elif node2[0][0] == 'B':

        travel_vector = node2[1] - node1[1][1]
        d_travel = np.linalg.norm(travel_vector)

        for uav in uavs.list:

            c_speed = uav.missionSettings['Nav. speed']

            W_t[uav.id] = d_travel / c_speed

            W_e1[uav.id] = compute_Consumption(travel_vector, c_speed, uav, weather)

        #print('SB')
        return W_t, W_e1
    
    # S to S
    else:

        if node2[0][0] == node1[1][0]:
            for uav in uavs.list:
                W_t[uav.id] = 0.0
                W_e1[uav.id] = 0.0
            print('SS2')
            return W_t, W_e1
        
        travel_vector = node2[0][1] - node1[1][1]
        d_travel = np.linalg.norm(travel_vector)

        insp_vector = node2[1][1] - node2[0][1]
        d_insp = np.linalg.norm(insp_vector)

        # UAVs are distinguished using their IDs, not their names
        for uav in uavs.list:

            c_speed = uav.missionSettings['Nav. speed']
            i_speed = uav.missionSettings['Insp. speed']

            W_t[uav.id] = d_insp / i_speed + d_travel / c_speed

            W_e1[uav.id] = compute_Consumption(travel_vector, c_speed, uav, weather)
            W_e2[uav.id] = compute_Consumption(insp_vector, i_speed, uav, weather)

        #print('SS')
        return W_t, {key: W_e1[key] + W_e2[key] for key in W_e1}

    return None, None

    



