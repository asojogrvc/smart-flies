# Solver code. As of now, everything is solved using SCIPI and its Python Interface PySCIPOpt

import networkx as nx, copy
import numpy as np
import itertools
from pyscipopt import Model, quicksum, SCIP_PARAMSETTING
from PyQt6.QtWidgets import QProgressBar

from modules import bases as BA, coordinates as CO, towers as TW, uav as UAVS, weather as WT, weights as WE

class PLI_problem():
    def __init__(self, Towers: TW.Towers, Bases: BA.Bases, Uavs: UAVS.UAV_Team, Weather = WT.Weather()):

        self.towers = Towers   
        self.bases = Bases   
        self.uav_team = Uavs
        self.weather = Weather

        self.graph = nx.MultiDiGraph()
        self.scipi_model = Model("PLI")

        self.progressBar = None

    def linkProgressBar(self, ui_progressbar: QProgressBar):
        """
        Connects a PyQt progress to the problem. Doing it this way so we can solve problems without UI
        """
        self.progressBar = ui_progressbar

    def solve(self, which_solver:str):

        # I might store the solution within UAVs and just pass a flag with the problem status

        match which_solver:
            case "regular":  # Javi's
                self.solution = regularSolver(self)
            case "abstract": # Alvaro's
                self.solution = abstractSolver(self)
            case "GRASP":    # Aerial-Core heuristic GRASP Method
                self.solution = GRASPSolver()

def regularSolver(problem: PLI_problem):

    # Maybe, to avoid using explicit ordering of stuff, you could pass data from networkx directly to SCIPI

    # --------------------------------- Graph ---------------------------------------------------------

    # First we need to construct the multi-directed-graph with all weights and attributes.
    # Instead of creating one copy of each edge for each UAV, lets just embed all UAVs Weights
    # into the attributes of the edges as dict. This allows some degrees of readbility of the abstract graph.
    
    problem.graph.add_nodes_from(problem.towers.graph.nodes(data = True))
    nx.set_node_attributes(problem.graph, 'Tower', 'type')

    tower_nodes = copy.deepcopy(problem.graph.nodes())

    # Iterate every pair of towers
    for pair in list(itertools.combinations(tower_nodes, 2)):

        # If the edge is on the original tower graph, is a power Line segment
        if problem.towers.graph.has_edge(pair[0], pair[1]):
            type1 = 'Sup'
            type2 = 'Sdown'
        # If it is not, them it is not a power line segment
        else:
            type1 = 'TT'
            type2 = 'TT'


        # One direction
        W_t, W_e = WE.compute_edge_Weights((pair[0], problem.graph._node[pair[0]]),
                           (pair[1], problem.graph._node[pair[1]]),
                            problem.uav_team, problem.weather)

        problem.graph.add_edge(pair[0], pair[1], type = type1, Wt = W_t, We = W_e)  

        # The other direction
        W_t, W_e = WE.compute_edge_Weights((pair[0], problem.graph._node[pair[0]]),
                           (pair[1], problem.graph._node[pair[1]]),
                            problem.uav_team, problem.weather)

        problem.graph.add_edge(pair[1], pair[0], type = type2, Wt = W_t, We = W_e) 

    base_list = []
    for base in problem.bases.list:
        base_list.append(base.name)

        problem.graph.add_node(base.name, UTM = base.coordinatesUTM, type = 'Base')
        for node in tower_nodes:

            W_t, W_e = WE.compute_edge_Weights((node, problem.graph._node[node]),
                               (base.name, problem.graph._node[base.name]),
                                problem.uav_team, problem.weather)
            
            problem.graph.add_edge(node, base.name, type = 'TB', Wt = W_t, We = W_e)

            W_t, W_e = WE.compute_edge_Weights((node, problem.graph._node[node]),
                               (base.name, problem.graph._node[base.name]),
                                problem.uav_team, problem.weather)
            
            problem.graph.add_edge(base.name, node, type = 'BT', Wt = W_t, We = W_e)

    # The current graph is a complete graph that connects all towers and bases with weighted edges
    # Now, lets setup SCIPI

    # --------------------------------- SCIPI ---------------------------------------------------------

    # Update progress bar if it is linked
    if not(problem.progressBar == None): problem.progressBar.setValue(25)

    # Add variables to the model

    Z = {}        # Type Binary free parameteres that active travels within a route
    Y = {}
    sigmas = {}   # Type Double 'free' parameters that measure time differences between UAV's paths

    t = {}        # To store ALL time weights as a dictionary
    e = {}        # To store ALL enery weights as a dictionary

    Wt = nx.get_edge_attributes(problem.graph, 'Wt')
    We = nx.get_edge_attributes(problem.graph, 'We')
    
    # Create the z variables on SCIPI. Also creates the t and e dictionaries
    for edge in problem.graph.edges():
            for uav in problem.uav_team.list:

                Z[edge[0]+'->'+edge[1]+'|'+uav.id] = problem.scipi_model.addVar(vtype = 'B',
                                                    name = 'z_{'+edge[0]+'->'+edge[1]+'|'+uav.id+'}')
                
                t[edge[0]+'->'+edge[1]+'|'+uav.id]  = Wt[(edge[0], edge[1], 0)][uav.id]
                e[edge[0]+'->'+edge[1]+'|'+uav.id]  = We[(edge[0], edge[1], 0)][uav.id]


    # The N(N-1)/2 UAVs pairs. No repetitions and no order.
    uav_pairs = list(itertools.combinations(problem.uav_team.list, 2))

    # Create the sigma variables on SCIPI. Also add the sigma definition constrains
    for pair in uav_pairs:
            sigmas[pair[0].id+','+pair[1].id] = problem.scipi_model.addVar(vtype = 'C',
                                                        name='sigma_{'+pair[0].id+','+pair[1].id+'}')

            # Sigma constrains

            """
            # Nonlinear version. Might freeze SCIP even if it is able to handle it
            problem.scipi_model.addCons(

                sigmas[pair[0].id+','+pair[1].id] 
                            >= 
                np.abs(quicksum(t[edge[0]+'->'+edge[1]+'|'+pair[0].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[0].id] 
                              - t[edge[0]+'->'+edge[1]+'|'+pair[1].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[1].id] 
                            for edge in problem.graph.edges()))

            )
            """
            # Linearized version. It is way less problematic
            problem.scipi_model.addCons(
                quicksum(t[edge[0]+'->'+edge[1]+'|'+pair[0].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[0].id] 
                              - t[edge[0]+'->'+edge[1]+'|'+pair[1].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[1].id] 
                            for edge in problem.graph.edges())
                - sigmas[pair[0].id+','+pair[1].id] 
                            <= 
                0.0
            )

            problem.scipi_model.addCons(
                quicksum(t[edge[0]+'->'+edge[1]+'|'+pair[1].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[1].id] 
                              - t[edge[0]+'->'+edge[1]+'|'+pair[0].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[0].id] 
                            for edge in problem.graph.edges())
                - sigmas[pair[0].id+','+pair[1].id] 
                            <= 
                0.0
            )

    # Lets define all constrain except for the already defined sigmas
    for uav in problem.uav_team.list:
        # Energy constrain. Used battery needs to be less than 100%
        problem.scipi_model.addCons(
            quicksum(e[edge[0]+'->'+edge[1]+'|'+uav.id] * Z[edge[0]+'->'+edge[1]+'|'+uav.id] 
                     for edge in problem.graph.edges()) 
                <= 
            1.0
        )

        # Starting and finishing at base.
        problem.scipi_model.addCons(
            quicksum(Z[uav.missionSettings['Base']+'->'+tower+'|'+uav.id] for tower in tower_nodes)
                ==
            1.0
        )

        problem.scipi_model.addCons(
            quicksum(Z[tower+'->'+uav.missionSettings['Base']+'|'+uav.id] for tower in tower_nodes)
                ==
            1.0
        )

        # Each UAV needs to exit a node (that is not a base, towers in this case) if it enters it
        # THIS DOES NOT ENSURE CONNECTIVITY. FIX
        
        for node1 in tower_nodes:
            other_towers = copy.deepcopy(list(problem.graph.nodes()))
            other_towers.remove(node1)
            problem.scipi_model.addCons(
                quicksum(Z[node2+'->'+node1+'|'+uav.id] - Z[node1+'->'+node2+'|'+uav.id] for node2 in other_towers)
                    ==
                0
            )
        
    """
    for node in tower_nodes:
        for uav in problem.uav_team.list:

            Y[node+','+uav.id] = problem.scipi_model.addVar(vtype = 'B',
                                                            name='Y_{'+node+','+uav.id+'}')
            
            other_towers = copy.deepcopy(list(problem.graph.nodes()))
            other_towers.remove(node)

            problem.scipi_model.addCons(
                quicksum(Z[node2+'->'+node+'|'+uav.id] + Z[node+'->'+node2+'|'+uav.id] for node2 in other_towers)
                    ==
                2 * Y[node+','+uav.id]
            )
    """

    # Select power line segments
    edges_types = nx.get_edge_attributes(problem.graph, 'type')
    power_lines = []
    for edge in edges_types:
        if edges_types[edge] == 'Sup': power_lines.append(edge)

    # ????? Ask JAVI ???????
    for edge in power_lines:
        problem.scipi_model.addCons(
            quicksum(Z[edge[0]+'->'+edge[1]+'|'+uav.id] + Z[edge[1]+'->'+edge[0]+'|'+uav.id]
                     for uav in problem.uav_team.list)
                ==
            1.0
        )

        problem.scipi_model.addCons(
            quicksum(Z[edge[0]+'->'+edge[1]+'|'+uav.id] for uav in problem.uav_team.list)
                <=
            1.0
        )

        problem.scipi_model.addCons(
            quicksum(Z[edge[1]+'->'+edge[0]+'|'+uav.id] for uav in problem.uav_team.list)
                <=
            1.0
        )
        
    # Let's set the objective function for SCIPI. Let's add a fixed parameter to tweak the importance
    # of each term. It should arrive at the same the solution regardless but it might help convergence

    f_k = 0.5 # This parameter requieres finetunning. It is useful not to fix it at 1.0

    problem.scipi_model.setObjective(quicksum(t[key]*Z[key] for key in Z.keys()) 
                                     + 
                                f_k * quicksum(sigmas[key] for key in sigmas.keys()))

    #print(problem.scipi_model.getObjective())

    #problem.scipi_model.setHeuristics(SCIP_PARAMSETTING.OFF) # Disable HEURISTICS
    #problem.scipi_model.disablePropagation()                 # Disable solution Propagation
    

    # Update progress bar if it is linked
    if not(problem.progressBar == None): problem.progressBar.setValue(30)

    # Write Scipi Problem externally into a human-readable file
    problem.scipi_model.writeProblem('scipi_model.cip')

    # Update progress bar if it is linked
    if not(problem.progressBar == None): problem.progressBar.setValue(35)

    # Optimize
    problem.scipi_model.optimize()

    # Update progress bar if it is linked
    if not(problem.progressBar == None): problem.progressBar.setValue(90)

    # Get the best solution
    sol = problem.scipi_model.getBestSol()

    print(problem.scipi_model.checkSol(sol))

    # --------------------------------- Routes Parsing ---------------------------------------------------------

    # Parse solution into each UAV Route

    # First reset every UAV Routes
    for uav in problem.uav_team.list:
        uav.route = []

    for edge in Z:
        if sol[Z[edge]] == 1.0:

            temp = edge.split('|')

            # Add edge to UAV Route. Later, it will be ordered.
            problem.uav_team.selectUAV(temp[1]).route.append(temp[0])

            nodes = temp[0].split('->')
            if nodes[0][0] == 'B' or nodes[1][0] == 'B':
                problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
            else:
                problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

    for uav_pair in sigmas:
        print('sigma_', uav_pair, ' = ' ,sol[sigmas[uav_pair]])

    for uav in problem.uav_team.list:
        print('NO = ', uav.route)
        uav.route, uav.routeModes = orderRoute(uav.missionSettings['Base'], uav.route, uav.routeModes)
        uav.routeUTM = routetoUTM(uav.route, problem.towers, problem.bases)
        print('O = ', uav.route)
        print(uav.routeModes)
    
    # Update progress bar if it is linked
    if not(problem.progressBar == None): problem.progressBar.setValue(100)

    return None

def abstractSolver(problem: PLI_problem):
    """
    This solves the problem using the abstract formulation where each power line segment is a node instead of an edge.
    Currently, charging stations are not implemented
    """

    #--------------------------------- Graph ---------------------------------------------------------

    # Add all S (Sup and Sdown) nodes
    # Iterate every pair of connected towers to create the segment nodes
    for line_segment in problem.towers.graph.edges():

        # Inspection in one direction. S^UPARROW
        problem.graph.add_node(
            'SUP_{'+line_segment[0]+','+line_segment[1]+'}'
            )
        
        # The other. S^DOWNARROW
        problem.graph.add_node(
            'SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'
            )
    
    # Prefetch all tower coordinates
    coords = nx.get_node_attributes(problem.towers.graph, 'UTM')

    # Add connection between S with itself
    # Iterate over all possible pairs of different line power segments
    for line_segment_pair in list(itertools.combinations(problem.towers.graph.edges(), 2)):

        # Parses the 2 towers pairs into nodes
        t1 = line_segment_pair[0][0]
        t2 = line_segment_pair[0][1]
        t3 = line_segment_pair[1][0]
        t4 = line_segment_pair[1][1]

        s1_tag = t1+','+t2
        s2_tag = t3+','+t4

        node1 = [(t1, coords[t1]), (t2, coords[t2])]
        node2 = [(t3, coords[t3]), (t4, coords[t4])]

        # Compute weights for each added edge

        # One edge direction 
        # Sup and Sup connection
        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1,
                                            node2,
                                            problem.uav_team,
                                            problem.weather)

        
        problem.graph.add_edge(
            'SUP_{'+s1_tag+'}',
            'SUP_{'+s2_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        # Sup and Sdown connection
        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1,
                                            node2[::-1],
                                            problem.uav_team,
                                            problem.weather)


        problem.graph.add_edge(
            'SUP_{'+s1_tag+'}',
            'SDOWN_{'+s2_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        # Sdown and Sdown connection
        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1[::-1],
                                            node2[::-1],
                                            problem.uav_team,
                                            problem.weather)

        problem.graph.add_edge(
            'SDOWN_{'+s1_tag+'}',
            'SDOWN_{'+s2_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        # Sdown and Sdown connection
        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1[::-1],
                                            node2,
                                            problem.uav_team,
                                            problem.weather)

        problem.graph.add_edge(
            'SDOWN_{'+s1_tag+'}',
            'SUP_{'+s2_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        # Now the same but with the edge in the other direction
        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2,
                                            node1,
                                            problem.uav_team,
                                            problem.weather)

        problem.graph.add_edge(
            'SUP_{'+s2_tag+'}',
            'SUP_{'+s1_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2,
                                            node1[::-1],
                                            problem.uav_team,
                                            problem.weather)


        problem.graph.add_edge(
            'SUP_{'+s2_tag+'}',
            'SDOWN_{'+s1_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2[::-1],
                                            node1[::-1],
                                            problem.uav_team,
                                            problem.weather)

        problem.graph.add_edge(
            'SDOWN_{'+s2_tag+'}',
            'SDOWN_{'+s1_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

        W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2[::-1],
                                            node1,
                                            problem.uav_team,
                                            problem.weather)

        problem.graph.add_edge(
            'SDOWN_{'+s2_tag+'}',
            'SUP_{'+s1_tag+'}',
            type = 'TT',
            Wt = W_t,
            We = W_e 
        )

    # Add base nodes and connect them with all S nodes
    for base in problem.bases.list:
        problem.graph.add_node(
            base.name
            )
        
        for line_segment in problem.towers.graph.edges():

            t1 = line_segment[0]
            t2 = line_segment[1]
            s_tag = t1+','+t2

            node1 = (base.name, base.coordinatesUTM)
            node2 = [(t1, coords[t1]), (t2, coords[t2])]

            W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1,
                                            node2,
                                            problem.uav_team,
                                            problem.weather)

            problem.graph.add_edge(
                base.name,
                'SUP_{'+s_tag+'}',
                type = 'BT',
                Wt = W_t,
                We = W_e
            )

            W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2,
                                            node1,
                                            problem.uav_team,
                                            problem.weather)

            problem.graph.add_edge(
                'SUP_{'+s_tag+'}',
                base.name,
                type = 'TB',
                Wt = W_t,
                We = W_e
            )

            W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node1,
                                            node2[::-1],
                                            problem.uav_team,
                                            problem.weather)

            problem.graph.add_edge(
                base.name,
                'SDOWN_{'+s_tag+'}',
                type = 'BT',
                Wt = W_t,
                We = W_e
            )

            W_t, W_e = WE.compute_abstract_edge_Weights(
                                            node2[::-1],
                                            node1,
                                            problem.uav_team,
                                            problem.weather)

            problem.graph.add_edge(
                'SDOWN_{'+s_tag+'}',
                base.name,
                type = 'TB',
                Wt = W_t,
                We = W_e
            )

    # With this, the abstract graph is fully constructed.     
        
    # ------------------------------ SCIP ------------------------------------
    # Let's define the SCIP problem, compute the solution and update the UAVs routes
    
    # Dictionaries to store SCIP variables
    Z = {}
    sigmas = {}
    Y = {}

    # Dictionaries to store weights for easy access
    t = {}
    e = {}

    Wt = nx.get_edge_attributes(problem.graph, 'Wt')
    We = nx.get_edge_attributes(problem.graph, 'We')

    # For each edge in the graph assign a Z variable and assign the corresponding weights
    # to its key in the weights dictionaries
    for edge in problem.graph.edges():

        for uav in problem.uav_team.list:

            edge_uav = edge[0]+'->'+edge[1]+'|'+uav.id # Edge|UAV Tag

            Z[edge_uav] = problem.scipi_model.addVar(vtype = 'B',
                                                  name = 'Z_{'+edge_uav+'}')
            
            t[edge_uav] = Wt[(edge[0], edge[1], 0)][uav.id]
            e[edge_uav] = We[(edge[0], edge[1], 0)][uav.id]

    # Only one inspection constrain
    for line_segment in problem.towers.graph.edges():

        nodelist = copy.deepcopy(list(problem.graph.nodes()))
        nodelist.remove('SUP_{'+line_segment[0]+','+line_segment[1]+'}')
        nodelist.remove('SDOWN_{'+line_segment[0]+','+line_segment[1]+'}')

        problem.scipi_model.addCons(
            quicksum(
                quicksum(Z[node+'->'+  'SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
                       + Z[node+'->'+'SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
                for uav in problem.uav_team.list)
            for node in nodelist)
                == 
            1.0
        )

        problem.scipi_model.addCons(
            quicksum(
                quicksum(Z[  'SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'->'+node+'|'+uav.id]
                       + Z['SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'->'+node+'|'+uav.id]
                for uav in problem.uav_team.list)
            for node in nodelist)
                == 
            1.0
        )

        # Continuity. The UAV that inspects must be the one that exits the segment
        for uav in problem.uav_team.list:

            Y['SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id] = problem.scipi_model.addVar(vtype = 'B',
              name = 'Y_{SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id+'}')

            problem.scipi_model.addCons(
                quicksum(Z[node+'->'+'SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
                       + Z['SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'->'+node+'|'+uav.id]
                for node in nodelist)
                    == 
                2 * Y['SUP_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
            )

            Y['SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id] = problem.scipi_model.addVar(vtype = 'B',
              name = 'Y_{SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id+'}')

            problem.scipi_model.addCons(
                quicksum(Z[node+'->'+'SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
                       + Z['SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'->'+node+'|'+uav.id]
                for node in nodelist)
                    == 
                2 * Y['SDOWN_{'+line_segment[0]+','+line_segment[1]+'}'+'|'+uav.id]
            )

    
    for uav in problem.uav_team.list:

        nodelist = copy.deepcopy(list(problem.graph.nodes()))

        for base in problem.bases.list:
            nodelist.remove(base.name)

        # Base exit constrain
        problem.scipi_model.addCons(
                quicksum(
                    Z[uav.missionSettings['Base']+'->'+node+'|'+uav.id]
                for node in nodelist)
                    == 
                1
        )

        # Base entering constrain
        problem.scipi_model.addCons(
                quicksum(
                    Z[node+'->'+uav.missionSettings['Base']+'|'+uav.id]
                for node in nodelist)
                    == 
                1
        )

        # Energy constrain
        problem.scipi_model.addCons(
            quicksum(e[edge[0]+'->'+edge[1]+'|'+uav.id] * Z[edge[0]+'->'+edge[1]+'|'+uav.id] 
                     for edge in problem.graph.edges()) 
                <= 
            1.0
        )


    # The N(N-1)/2 UAVs pairs. No repetitions and no order.
    uav_pairs = list(itertools.combinations(problem.uav_team.list, 2))

    # Create the sigma variables on SCIP. Also add the sigma definition constrains
    for pair in uav_pairs:
            pair_tag = pair[0].id+','+pair[1].id
            sigmas[pair_tag] = problem.scipi_model.addVar(vtype = 'C',
                                                        name='sigma_{'+pair_tag+'}')

            # Sigma constrains
            # Linearized version. It is way less problematic
            
            problem.scipi_model.addCons(
                quicksum(t[edge[0]+'->'+edge[1]+'|'+pair[0].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[0].id] 
                       - t[edge[0]+'->'+edge[1]+'|'+pair[1].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[1].id] 
                            for edge in problem.graph.edges())
                - sigmas[pair_tag] 
                            <= 
                0.0
            )

            problem.scipi_model.addCons(
                quicksum(t[edge[0]+'->'+edge[1]+'|'+pair[1].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[1].id] 
                       - t[edge[0]+'->'+edge[1]+'|'+pair[0].id] * Z[edge[0]+'->'+edge[1]+'|'+pair[0].id] 
                            for edge in problem.graph.edges())
                - sigmas[pair_tag] 
                            <= 
                0.0
            )

    f_k = 1.0 #0.5 # This parameter requieres finetunning. It is useful not to fix it at 1.0

    problem.scipi_model.setObjective(quicksum(t[key]*Z[key] for key in Z.keys()) 
                                     + 
                                f_k * quicksum(sigmas[key] for key in sigmas.keys()))

    #print(problem.scipi_model.getObjective())

    #problem.scipi_model.setHeuristics(SCIP_PARAMSETTING.OFF) # Disable HEURISTICS
    #problem.scipi_model.disablePropagation()                 # Disable solution Propagation

    # Write Scipi Problem externally into a human-readable file
    problem.scipi_model.writeProblem('scipi_model.cip')
            
    problem.scipi_model.optimize()
    sol = problem.scipi_model.getBestSol()

    print(problem.scipi_model.checkSol(sol))

    # -------------------- Route parsing -----------------------------

    for uav in problem.uav_team.list:
        uav.route = []
        uav.routeAbstract = []
    
    for edge in Z:

        if np.abs(sol[Z[edge]] - 1.0) < 1e-6: # To avoid floating point errors
            
            
            temp = edge.split('|')

            # problem.uav_team.selectUAV(temp[1]).route.append(temp[0])

            nodes = temp[0].split('->')

            problem.uav_team.selectUAV(temp[1]).routeAbstract.append(temp[0])

            
            print(nodes, temp[1])

            # B to S
            if nodes[0][0] == 'B':

                print('B to S')
                
                mode_segment = nodes[1].split('_')
                towers = mode_segment[1][1:-1].split(',')

                # Add edges to UAV Route. Later, it will be ordered.
                if mode_segment[0] == 'SUP':
                    # Base to Tower
                    problem.uav_team.selectUAV(temp[1]).route.append(nodes[0]+'->'+towers[0])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                    # Inspection SUP
                    problem.uav_team.selectUAV(temp[1]).route.append(towers[0]+'->'+towers[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')
                else:
                    # Base to Tower
                    problem.uav_team.selectUAV(temp[1]).route.append(nodes[0]+'->'+towers[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                    # Inspection SDOWN
                    problem.uav_team.selectUAV(temp[1]).route.append(towers[1]+'->'+towers[0])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

            # S to B
            elif nodes[1][0] == 'B':

                print('S to B')

                mode_segment = nodes[0].split('_')
                towers = mode_segment[1][1:-1].split(',')

                # Add edges to UAV Route. Later, it will be ordered.
                if mode_segment[0] == 'SUP':
                    # Inspection SUP
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers[0]+'->'+towers[1])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')
                    # Base to Tower
                    problem.uav_team.selectUAV(temp[1]).route.append(towers[1]+'->'+nodes[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                else:
                    # Inspection SDOWN
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers[1]+'->'+towers[0])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')
                    # Base to Tower
                    problem.uav_team.selectUAV(temp[1]).route.append(towers[0]+'->'+nodes[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')

            # S to S
            else:

                print('S to S')

                mode_segment1 = nodes[0].split('_')
                towers1 = mode_segment1[1][1:-1].split(',')

                mode_segment2 = nodes[1].split('_')
                towers2 = mode_segment2[1][1:-1].split(',')

                if mode_segment1[0] == 'SUP' and mode_segment2[0] == 'SUP':

                    # Inspection SUP 1
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers1[0]+'->'+towers1[1])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')
                    
                    # Tower to Tower movement
                    if towers1[1] != towers2[0]:
                        problem.uav_team.selectUAV(temp[1]).route.append(towers1[1]+'->'+towers2[0])
                        problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                    # Inspection SUP 2
                    problem.uav_team.selectUAV(temp[1]).route.append(towers2[0]+'->'+towers2[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                elif mode_segment1[0] == 'SUP' and mode_segment2[0] == 'SDOWN':

                    # Inspection SUP 1
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers1[0]+'->'+towers1[1])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                    # Tower to Tower movement
                    if towers1[1] != towers2[1]:
                        problem.uav_team.selectUAV(temp[1]).route.append(towers1[1]+'->'+towers2[1])
                        problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                    # Inspection SDOWN 2
                    problem.uav_team.selectUAV(temp[1]).route.append(towers2[1]+'->'+towers2[0])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                elif mode_segment1[0] == 'SDOWN' and mode_segment2[0] == 'SUP':
                    
                    # Inspection SDOWN 1
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers1[1]+'->'+towers1[0])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                    # Tower to Tower movement
                    if towers1[0] != towers2[0]:
                        problem.uav_team.selectUAV(temp[1]).route.append(towers1[0]+'->'+towers2[0])
                        problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')

                    # Inspection SUP 2
                    problem.uav_team.selectUAV(temp[1]).route.append(towers2[0]+'->'+towers2[1])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                else:

                    # Inspection SDOWN 1
                    # problem.uav_team.selectUAV(temp[1]).route.append(towers1[1]+'->'+towers1[0])
                    # problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')

                    # Tower to Tower movement
                    if towers1[0] != towers2[1]:
                        problem.uav_team.selectUAV(temp[1]).route.append(towers1[0]+'->'+towers2[1])
                        problem.uav_team.selectUAV(temp[1]).routeModes.append('Navigation')
                    # Inspection SDOWN 2
                    problem.uav_team.selectUAV(temp[1]).route.append(towers2[1]+'->'+towers2[0])
                    problem.uav_team.selectUAV(temp[1]).routeModes.append('Inspection')
            
            print('t = ', problem.uav_team.list[0].route)

    for uav_pair in sigmas:
        print('sigma_', uav_pair, ' = ' ,sol[sigmas[uav_pair]])

    for uav in problem.uav_team.list:
        print('NO = ', uav.route)
        uav.route, uav.routeModes = orderRoute(uav.missionSettings['Base'], uav.route, uav.routeModes)
        uav.routeUTM = routetoUTM(uav.route, problem.towers, problem.bases)
        print('O = ', uav.route)
        print(uav.routeModes)

    return None

def GRASPSolver():
    """
    Using the abstractSolver, let's implement the GRASP method to find a solution. To be implement
    """
    # TBD
    return None

def orderRoute(start: str, edge_list: list, mode_list:list):
    """
    Given and unordered route, it orders following the nodes from the starting base.
    It suposses that routes are closed and if it has any subroutes or ambiguity it will
    take a choice based on ordering and order each subpath.

    Here, the graph considered is physical and not the abstract one.

    # NOT FULLY TESTED CODE. MIGHT ENTER INFINITE LOOP
    """

    n_e = len(edge_list)

    orderedRoute = []
    orderedModes = []

    # Search for the exit base edge
    foundQ = False
    for k in range(n_e):
        edge_l = edge_list[k].split('->')
        if edge_l[0] == start:
            foundQ = True
            break
    
    # If no base is found, start the ordering from the first node on the route
    if not(foundQ):
        print('orderRoute::Start node is not in the route')
    orderedRoute.append((edge_l[0], edge_l[1]))
    orderedModes.append(mode_list[k])
    # Delete edge from list
    del edge_list[k]
    del mode_list[k]

    # From there, continue connecting consecutive edges
    while not(len(orderedRoute) == n_e):
        foundQ = False
        for k in range(len(edge_list)):
            edge_l = edge_list[k].split('->')
            if edge_l[0] == orderedRoute[-1][1]:
                foundQ = True
                break

        # If the next node is found, add it to the ordered list        
        if foundQ:
            orderedRoute.append((edge_l[0], edge_l[1]))
            orderedModes.append(mode_list[k])
            # Delete edge from list
            del edge_list[k]
            del mode_list[k]
        # If it is not found and there are nodes left, them the route
        # has subroutes. Order the subroute and continue
        else:
            print('orderRoute::Route has two or more disjoint subpaths')
            temp, temp_m = orderRoute(edge_list[0].split('->')[0], edge_list, mode_list)
            orderedRoute += temp
            orderedModes += temp_m
    
    # The ordering stops when the ordered route has the same number of nodes as
    # the initial route
    return orderedRoute, orderedModes

def routetoUTM(route: list, towers: TW.Towers, bases:BA.Bases):
    """
    Transforms each node on each edge of the route tu UTM coordinates.
    Return a list with a 2-tuple (UTM1, UTM2) per original edge
    """
    routeUTM = []
    for edge in route:
        
        if edge[0][0] == 'B':
                UTM1 = bases.get_Base(edge[0]).coordinatesUTM
                UTM2 = towers.graph._node[edge[1]]['UTM']
        
        elif edge[1][0] == 'B':
                UTM1 = towers.graph._node[edge[0]]['UTM']
                UTM2 = bases.get_Base(edge[1]).coordinatesUTM
        
        else:
            UTM1 = towers.graph._node[edge[0]]['UTM']
            UTM2 = towers.graph._node[edge[1]]['UTM']
        
        routeUTM.append((UTM1, UTM2))

    return routeUTM


