# Base and Bases class

import numpy as np
import re
from pykml import parser
import modules.coordinates as CO
import matplotlib as mpl
import matplotlib.pyplot as plt


class Base():
    def __init__(self, _name:str = 'tower', coordinatesutm: np.ndarray = np.array([0.0, 0.0, 0.0])):
        """
        A base is described by its name and UTM coordinates (with altitud).
        """

        self.name = _name

        # Already UTM. By component
        self.E = coordinatesutm[0]
        self.N = coordinatesutm[1]
        self.z = coordinatesutm[2]

        # As a 3D vector
        self.coordinatesUTM = coordinatesutm

    
    def getUTMcoordinates(self):
        """
        Not necessary auxiliary method to obtatin UTM coordinates of a base
        """
        return self.coordinatesUTM
    
    
    def plot(self, axes: mpl.axes._axes.Axes):
            """
            Auxiliary method that connects with an already existing matplotlib figure via axes
            """
            axes.plot(self.coordinatesUTM[0], self.coordinatesUTM[1], 'ro')
            axes.text(self.coordinatesUTM[0], self.coordinatesUTM[1], self.name, fontsize = 14)


class Bases():
    def __init__(self, _list:list = [], _utm_Zone_Number: int = 0,_utm_Zone_Letter: str = "A"):
        """
        The Bases class is just a list of bases with additional methods and properties for easy coding
        It also contains the UTM Zone assigned to all bases with it (If bases are in differente UTM Zones, the planner
        will crash)
        """

        self.list = _list # Where base instances will be stored

        self.coordinates_List = np.empty((len(self.list),3))

        # If the list is not empty, set coordinate list as an Nx3 numpy array
        if self.list:

            k = 0
            for base in self.list:
                self.coordinates_List[k, :] = base.coordinatesUTM
                k += 1

        self.utm_Zone_Letter = _utm_Zone_Letter
        self.utm_Zone_Number = _utm_Zone_Number 

    # Iterator method so we can use "for base in bases". Should be good.
    # This method just initialize things
    def __iter__(self):
        self.iter_counter = 0
        self.iter_max = len(self.list)
        return self
    # Should give the next element each time it is called
    def __next__(self):
        # Sets maximum number of iterations
        if self.iter_counter < (self.iter_max): # self.iter_max might be changed to self.number_of_bases
                                                # len(self.list) cannot be used as it will create infinite loops
                                                # if the list length is changed within an iteration
            self.iter_counter += 1
            return self.list[self.iter_counter-1]
        else:
            raise StopIteration

    
    def add_Base(self, base: Base):
        """
        Self explanatory. It might be a good idea to check if the new base is at the same UTM Zone
        """
        
        self.list.append(base)
        self.coordinates_List = np.vstack((self.coordinates_List, base.coordinatesUTM))

    def remove_Base(self, which: int):
        """
        Not sure if it works. Not used anywhere
        """

        del self.list[which]
        del self.coordinates_List[which,:]

    def get_Base(self, name: str):
        """
        Outputs a base within the bases list based on its unique name
        """
        for base in self.list:
            if base.name == name:
                return base
            
        return None

    
    def reset(self):
        """
        Resets the bases list to its default state
        """
        self.list = []
        self.coordinates_List = np.empty((len(self.list),3))
        self.utm_Zone_Letter = "A"
        self.utm_Zone_Number = "0"

    
    def loadFile(self, file: str, onlineQ: bool):
        """
        Method that updates a bases list using an offline file
        If the boolean "onlineQ" is True, height coordinates will be updated online
        using a WEB API
        """

        # First reset the list in case there is any data already in it
        self.reset()

        # Can parse local file, string variable or from URL
        # https://pythonhosted.org/pykml/tutorial.html#parsing-existing-kml-documents

        # Load kml file
        with open(file) as f:
            doc = parser.parse(f).getroot()
            f.close()

        # Parse kml data for each base and adds it to the list
        base_number = 1
        for point in doc.Document.Folder.Placemark:
            # Parsing string
            pathstr = np.array(re.split(',| ', point.Point.coordinates.text.strip()))

            # From string to float conversion of coords
            pointlatlon = pathstr.astype(float)
            # Online Height Update
            if onlineQ:
                CO.updateHeightOnline(pointlatlon)

            # We need to change from latlon to UTM coords
            pointn, Z_number, Z_letter = CO.latlon2utm(pointlatlon)

            # Create the base instance and adds it to the list
            base = Base(f"B{base_number}", pointn)

            self.add_Base(base)
            base_number += 1

        # Set UTM Zone of the bases
        self.utm_Zone_Letter = Z_letter
        self.utm_Zone_Number = Z_number

    def plot(self, axes: mpl.axes._axes.Axes):
        """
        Auxiliary method that connects with an already existing matplotlib figure via axes.
        It just plots every base within the base list
        """
        for base in self:
            base.plot(axes)

