import numpy as np
import requests
import utm
from urllib.request import urlopen
from io import BytesIO
from PIL import Image
#import matplotlib.ticker as plticker

# [longitude, latitud] Be careful as they are flipped here


def latlon2utm(llcoord: np.ndarray):
    """
    latitud-longitud to UTM coordinates conversion. It is based on the 'utm' module and it only
    manages shape details.
    Should work with (N, 2) arrays. If the z coordinate is given, It should spit it out too
    """

    # If llcord is 2D or 3D
    if llcoord.shape == (2,):
        # lat, lon
        E, N, Z_number, Z_letter = utm.from_latlon(llcoord[1], llcoord[0])
        return np.array([E, N]), Z_number, Z_letter
    
    elif llcoord.shape == (3,):
        # lat, lon
        E, N, Z_number, Z_letter = utm.from_latlon(llcoord[1], llcoord[0])
        return np.array([E, N, llcoord[2]]), Z_number, Z_letter
    
    else:
        E, N, Z_number, Z_letter = utm.from_latlon(llcoord[:,1], llcoord[:,0])
        if len(llcoord[0]) > 2:
            return np.transpose(np.vstack((E, N, llcoord[:,2]))), Z_number, Z_letter
        
        else:
            return np.transpose(np.vstack((E, N))), Z_number, Z_letter

def utm2latlon(utmcoord: np.ndarray, zone_number: int, zone_letter:str):
    """
    UTM to latitud-longitud coordinates conversion. It is based on the 'utm' module and it only
    manages shape details.
    Should work with (N, 2) arrays. If the z coordinate is given, It should spit it out too
    """

    # If utmcoord is 1D or not
    if utmcoord.shape == (2,):
        # E, N
        lat, lon = utm.to_latlon(utmcoord[0], utmcoord[1], zone_number, zone_letter)
        return np.transpose(np.vstack((lon, lat)))
    elif utmcoord.shape == (3,):
        # E, N
        lat, lon = utm.to_latlon(utmcoord[0], utmcoord[1], zone_number, zone_letter)
        return np.transpose(np.vstack((lon, lat, utmcoord[2])))
    
    else:
        lat, lon = utm.to_latlon(utmcoord[:,0], utmcoord[:,1], zone_number, zone_letter)
        if len(utmcoord[0]) > 2:
            return np.transpose(np.vstack((lon, lat, utmcoord[:,2])))
        
        else:
            return np.transpose(np.vstack((lon, lat)))

def updateHeightOnline(coords: np.ndarray):
    """
    Function to update a point's height using the online API:
        opentopodata.org
    """

    url = 'https://api.opentopodata.org/v1/eudem25m?locations='

    # Check whether coords is just a point or several and if it is 2D or 3D
    if coords.shape == (2,):
        # If it 2D, leave it as it is
        return
    elif coords.shape == (3,):
        # If it is a point 3D, then update the height

        # request url
        request = url + f"{coords[1]}"+','+f"{coords[0]}"+'|'
        # get response from the api
        print(request)
        response = requests.get(request, timeout=10.0)
        

        # if the response is positive, update, if not, don't
        if response.status_code == 200:
            coords[2] = response.json()["results"][0]["elevation"]

        return
    else:
        # if instead of a single point if a list of them

        # Check if the points are 2D
        if coords.shape[1] == 2:
            return 
        
        # If not, update their height
        else:

            towers_string = ""
            for col in coords:
                towers_string = towers_string+f"{col[1]}"+','+f"{col[0]}"+'|'

            request = url + towers_string
            print(request)
            response = requests.get(request, timeout=10.0)

            elevations = np.zeros(len(coords))
            if response.status_code == 200:
                for k in range(len(coords)):
                    elevations[k] = response.json()["results"][k]["elevation"]

            coords[:,2] = elevations
            

            return
        
def latlon2mercator(lat_deg, lon_deg, zoom):
  """
  Transformation from latitude-longitud (degrees) to Web mercator with an specific zoom level
  """
  lat_rad = np.radians(lat_deg)
  n = 2.0 ** zoom
  xtile = int((lon_deg + 180.0) / 360.0 * n)
  ytile = int((1.0 - np.log(np.tan(lat_rad) + (1 / np.cos(lat_rad))) / np.pi) / 2.0 * n)
  return [xtile, ytile]
  
def mercator2latlon(xtile, ytile, zoom):
  """
  Transformation from Web Mercator to Latitude-Longitude (degrees) with an specific zoom level
  """
  n = 2.0 ** zoom
  lon_deg = xtile / n * 360.0 - 180.0
  lat_rad = np.arctan(np.sinh(np.pi * (1 - 2 * ytile / n)))
  #lat_rad = 2*np.arctan(np.exp(np.pi * (1 - 2 * ytile / n)))-np.pi/2 # It is the same
  lat_deg = np.degrees(lat_rad)
  return np.asarray([lat_deg, lon_deg])

def getImageCluster(lat_deg, lon_deg, delta_lat, delta_long, zoom):
    """
    Get image from a tile cluster obtained through Google Maps' API using coordinates.
    
        - lat_deg and lon_deg are the aprox Latitud and Longitud for center of the top left corner tile of the cluster
          given in degrees (Mercator coord are discretized depending on  zoom level or number of tiles).
        - delta_lat and delta_long are the coordinates width and height offset for the bottom right tile
          given in degrees.
        - zoom level. Each zoom level gives a 2-fold increase in the number of necessary tiles. If it is too high,
          the API won't respond.

    For a fixed zoom, each tile of the map has some Mercator coordinates. The higher the zoom, the smaller the
    area a tile represents and the more close its center will be to the aprox. coordinates give. Those tiles are 
    always 256x256px each and can be combined to obtain an entire image. For each higher zoom level, more tiles are needed
    to compile the entire image of the same area. 

    References:
        - https://en.wikipedia.org/wiki/Web_Mercator_projection
        - https://en.wikipedia.org/wiki/Mercator_projection
    """

    # Define the base URL for the API
    smurl = r"https://mt.google.com/vt/lyrs=s&x={0}&y={1}&z={2}"

    # Define the two Mercator points that enclosed the area
    xmin, ymax = latlon2mercator(lat_deg, lon_deg, zoom)
    xmax, ymin = latlon2mercator(lat_deg + delta_lat, lon_deg + delta_long, zoom)
    
    # Get the image as cluster of 256x256px tiles
    Cluster = Image.new('RGB',((xmax-xmin+1)*256-1,(ymax-ymin+1)*256-1), color = 'white') 
    for xtile in range(xmin, xmax+1):
        failedQ = False
        for ytile in range(ymin,  ymax+1):
            try:
                imgurl=smurl.format(xtile, ytile, zoom)
                #print("Opening: " + imgurl)
                imgstr = urlopen(imgurl).read()
                tile = Image.open(BytesIO(imgstr))
                Cluster.paste(tile, box=((xtile-xmin)*256 ,  (ytile-ymin)*255))
                print("Opened: " + imgurl)
            except:
                print("Failed at: " + imgurl)
                failedQ = True
                break
        
        # If any tile fails to download, stop
        if failedQ:
            break

    # Return tile cluster as an image and the latlon coord of the two bounding tiles
    return Cluster, mercator2latlon(xmin, ymax, zoom), mercator2latlon(xmax, ymin, zoom)

def plotSatellitalMap(axes, image: np.ndarray, latlon1: np.ndarray, latlon2: np.ndarray, zoom:int):
    """
    Auxiliary function that projects a satellital image to its coordinates on a already existing matplotlib canvas
    It takes into account the discrete nature of the web mercator/image tiles that the image represents
    """

    # Compute degrees of latlon per pixel of the image
    deg_p_px_X = np.abs(latlon2[1]-latlon1[1])/(image.shape[1]-255)
    deg_p_px_Y = np.abs(latlon2[0]-latlon1[0])/(image.shape[0]-255)

    # Assign coordinates to top left and bootom right pixels
    # taking into account some Mercator nuisances
    latlon_e1 = np.asarray([latlon1[1], latlon1[0]-255*deg_p_px_Y])
    latlon_e2 = np.asarray([latlon2[1]+255*deg_p_px_X, latlon2[0]])

    # to UTM
    utm1, _, _ = latlon2utm(latlon_e1)
    utm2, _, _ = latlon2utm(latlon_e2)

    # Plot image projected into the UTM coordinates
    axes.imshow(image, extent = [utm1[0], utm2[0], utm1[1], utm2[1]], alpha = 0.7)

def computeParallelTrajectory(current_pos: np.ndarray, segment: tuple, offset: float):
    """
    Given the current position and the next movement, compute the waypoints for the parallel inspection trajectory at offset
    """

    s1 = segment[0][:2]
    s2 = segment[1][:2]

    if (s2 == s2).all(): 
        print("ComputeTrajectories: huh?")

    n_dir = s2 - s1
    n_dir = n_dir / np.linalg.norm(n_dir)

    n_perp = np.asarray([n_dir[1], -n_dir[0]])

    p1 = s1 + offset * n_perp
    p2 = s1 - offset * n_perp

    if np.linalg.norm(p1-current_pos) <= np.linalg.norm(p2-current_pos):
        p3 = s2 + offset * n_perp
        return (p1, p3), n_dir, -n_perp # n_perp goes from the tower to the previuos point
    else: 
        p3 = s2 - offset * n_perp
        return (p2, p3), n_dir, n_perp

